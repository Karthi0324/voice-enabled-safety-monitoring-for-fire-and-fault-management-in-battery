#include <LiquidCrystal.h>
LiquidCrystal lcd(13,12, 11, 10, 9, 8);

#include <Adafruit_Sensor.h>
#include "DHT.h"
#define DHTPIN 2   // what pin we're connected to
#define DHTTYPE DHT11   // DHT 11 

int t;

DHT dht(DHTPIN, DHTTYPE);


//////////////////////////////voltage1////////////////

float correctionfactor1 = 0; 
int analogInput1 = A1; //voltage
float vout1 = 0.0; 
float vin1 = 0.0; 
 
// two resistors 30K and 7.5k ohm
float R1_1 = 30000;  //   
float R2_1 = 7500; //  
float value1 = 0.0;
///////////////////////////////////////////////////////


int x,y,z;

int R;

int Z2,Z1;

int vin1_1;

int s,f;

int F;

void setup()
{
dht.begin();
     /*******************************/
      Serial.begin(9600);
      lcd.begin (16,2);  
      /*******************************/
      lcd.setCursor(0,0);
      lcd.print("EV Battery ");
      lcd.setCursor(0,1);
      lcd.print("Management System ");
   
      /**********************************************/
        
    pinMode(A1,INPUT);  //volt 1
  
                      
pinMode(2,INPUT);// temp

pinMode(7,INPUT);// fire


pinMode(3,OUTPUT);//motor

pinMode(5,OUTPUT);//buzzer
   delay(3000);
      lcd.clear();
             
}

/*****************************************************************/
void loop() 
{
  
 dht11();
 
voltage1();

if( (f==1)||(s==1) )  /////fire and buzzer contion 
    {
      
       digitalWrite(5,HIGH); 
         delay(1000);
       digitalWrite(5,LOW);         
      } 

else if( (f==0)||(s == 0))
{


digitalWrite(5,LOW); 
      
}
             
 F=digitalRead(7);

if(F==LOW)   ////fire sensor
{
  lcd.setCursor(7,1);
  
  lcd.print("F_H");
  
f=1;

 digitalWrite(3,HIGH);
}

else
{
  
lcd.setCursor(7,1);

lcd.print("F_L");

f=0;

digitalWrite(3,LOW);

} 



   Serial.println("T");
    Serial.println(t);
    delay(200);

    Serial.println("S");
   Serial.println(s); 
   delay(200);
    
    Serial.println("a");
    Serial.println(vin1); 
   delay(200);
 
      Serial.println("b");
   Serial.println(vin1_1); 
   delay(200);


    Serial.println("d");
   Serial.println(f); 
   delay(200);
   

              
}

void voltage1()
{

    value1 = analogRead(analogInput1); 
    vout1 = (value1 * 5) / 1023.0; // see text 
    vin1 = vout1 / (R2_1/(R1_1+R2_1));
 
    vin1 = vin1+0.7 - correctionfactor1; 
    
    lcd.setCursor(0,0);
    lcd.print("V:");
    lcd.setCursor(2,0);
    lcd.print(vin1);


vin1_1=((vin1/12)*100);


  lcd.setCursor(8,0);
    lcd.print("BP:");
    lcd.print(vin1_1);
    lcd.print("% ");
    

     
}



 void dht11()
{
  
       
      
 int h = dht.readHumidity();
         t = dht.readTemperature();
        float f = dht.readTemperature(true);
        
        if (isnan(h) || isnan(t) || isnan(f)) 
        {
          //Serial.println("Failed to read from DHT sensor!");
          return;
        }
               
         lcd.setCursor(11,1);
         lcd.print("T:");

         lcd.setCursor(13,1);
         lcd.print(t); 

 if(t > 38)   /////temp
        {
     lcd.setCursor(15,1);
 lcd.print("H");

 s=1;  ///temp high motor offf buzzer on
// digitalWrite (4,HIGH);
        }
        else
        {
      lcd.setCursor(15,1);
      lcd.print("L");

  s=0; /////temp low motor on buzzer offf
//    digitalWrite (4,LOW);
        }
  
}
